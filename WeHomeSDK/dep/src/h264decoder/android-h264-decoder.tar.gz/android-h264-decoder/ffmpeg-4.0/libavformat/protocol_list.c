static const URLProtocol * const url_protocols[] = {
    NULL };
